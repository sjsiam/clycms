<?php

abstract class Controller
{
    protected $db;
    protected $theme;
    protected $sharedData = [];

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    protected function view($template, $data = [])
    {
        extract($data);
        
        // Make $app available to views for plugin hooks
        global $app;

        $viewFile = APP_PATH . '/views/' . $template . '.php';

        if (!file_exists($viewFile)) {
            throw new Exception("View file not found: {$template}");
        }

        include $viewFile;
    }

    protected function json($data)
    {
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }

    protected function redirect($url, $data = [])
    {
        if (!empty($data)) {
            if (session_status() === PHP_SESSION_NONE) {
                session_start();
            }

            foreach ($data as $key => $value) {
                $_SESSION[$key] = $value;
            }
        }
        header("Location: {$url}");
        exit;
    }

    protected function renderTheme($template, $data = [])
    {
        $data = array_merge($this->sharedData, $data);

        $themeFile = THEMES_PATH . '/' . $this->theme . '/' . $template . '.php';

        if (!file_exists($themeFile)) {
            $themeFile = THEMES_PATH . '/default/' . $template . '.php';
        }

        if (!file_exists($themeFile)) {
            throw new Exception("Theme template not found: {$template}");
        }

        extract($data);
        
        // Make $app available to theme templates for plugin hooks
        global $app;
        
        include $themeFile;
    }

    protected function requireAuth()
    {
        if (!Auth::check()) {
            $this->redirect('/admin/login');
        }
    }

    protected function requireRole($role)
    {
        $this->requireAuth();
        if (!Auth::hasRole($role)) {
            http_response_code(403);
            $this->view('errors/403');
            exit;
        }
    }
}
