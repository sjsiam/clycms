<?php

class RouteNotFoundException extends Exception {
    //Silnce is golden
}
